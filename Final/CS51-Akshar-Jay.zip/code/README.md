Within the code directory that this README file is also in, we have created a Makefile for easy compilation.

Execute 'make' in order to create executable versions of all the files.

The file that you will want to run is test.ml by executing './test.native'

You will see that our code passes all the tests in the file. 

Please feel free to look around at the code and the tests!